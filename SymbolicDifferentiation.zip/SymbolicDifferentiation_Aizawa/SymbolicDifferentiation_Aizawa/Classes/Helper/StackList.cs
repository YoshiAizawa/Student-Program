﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SymbolicDifferentiation_Aizawa
{
    public class StackList<T> : IStack<T>
    {
        private ILinkedList<T> _items;

        public StackList()
        {
            _items = new DoublyLinkedList<T>();
        }

        public T Peek()
        {
            if (IsEmpty) throw new InvalidOperationException("Stack is Empty.");
            var nodeData = _items.Head.Data;
            return nodeData;
        }

        public T Pop( )
        {
            if (IsEmpty) throw new InvalidOperationException("Stack is Empty.");
            var nodeData = _items.Head.Data;
            _items.RemoveFromHead();
            return nodeData;
        }

        public void Push(T data)
        {
            _items.AddToHead(data);
        }

        public bool IsEmpty
        {
            get
            {
                if (_items.Count == 0)
                    return true;
                else
                    return false;
            }
        }

        public int Count
        { 
            get
            {
                return _items.Count;
            }
        }

        public void Clear()
        {
            var anotherList = new DoublyLinkedList<T>();
            _items = anotherList;
        }

        public IEnumerator<T> GetEnumerator()
        {
            return _items.GetEnumerator();
        }
    }
}
