﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SymbolicDifferentiation_Aizawa
{
    public interface IStack<T>
    {
        /// <summary>
        /// Push data unto the the top of the stack.
        /// </summary>
        /// <param name="data">The data to push. Any type is accepted.</param>
        void Push(T data);

        /// <summary>
        /// Removes the top of the stack.
        /// </summary>
        /// <returns>Returns the data from the top of the stack</returns>
        T Pop();

        /// <summary>
        /// Looks at the data at the top of the stack without removing it.
        /// </summary>
        /// <returns>Returns the data from the top of the stack</returns>
        T Peek();

        /// <summary>
        /// Returns true if the stack contains no data
        /// </summary>
        bool IsEmpty { get; }
         
        /// <summary>
        /// Returns the number of items
        /// </summary>
        int Count { get; }

        /// <summary>
        /// Clears the item
        /// </summary>
        void Clear();

        /// <summary>
        /// reads one by one
        /// </summary>
        /// <returns></returns>
        IEnumerator<T> GetEnumerator();
    }
}
