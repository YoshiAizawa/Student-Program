﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SymbolicDifferentiation_Aizawa
{
    public interface IQueue<T>
    {
        void Enqueue(T data);
        T Dequeue();
        T Peek();
        int Count { get;  }
        bool IsEmpty { get; }
        void Clear();
        IEnumerator<T> GetEnumerator();
        bool HasSameContents(IQueue<T> other, IComparer<T> comparer = null);
        bool HasEquivalentContens(IQueue<T> other, IComparer<T> comparer = null);
        void Swap(IQueue<T> other);
        void Flip();
        IQueue<T> CloneLeftToRight();
        IQueue<T> CloneRightToLeft();

    }
}
