﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SymbolicDifferentiation_Aizawa
{
    public class QueueList<T> : IQueue<T>
    {
        private ILinkedList<T> _items;
        public QueueList()
        {
            _items = new DoublyLinkedList<T>();
        }

        public int Count
        {
            get
            {
                return _items.Count;
            }
        }

        public bool IsEmpty
        {
            get
            {
                if (_items.Count == 0)
                    return true;
                else
                    return false;
            }
        }

        public void Clear()
        {
            var anotherList = new DoublyLinkedList<T>();
            _items = anotherList;
        }

        public IQueue<T> CloneLeftToRight()
        {
            var newQueue = new QueueList<T>();

            foreach (var item in _items)
            {
                newQueue.Enqueue(item);
            }

            return newQueue;
        }

        public IQueue<T> CloneRightToLeft()
        {
            var tmpQueue = CloneLeftToRight();
            var tmpStack = new StackList<T>();

            while (tmpQueue.Count != 0)
            {
                tmpStack.Push(tmpQueue.Dequeue());
            }

            var newQueue = new QueueList<T>();
            while (tmpStack.Count != 0)
            {
                newQueue.Enqueue(tmpStack.Pop());
            }

            return newQueue;
        }

        public T Dequeue()
        {
            if (IsEmpty) throw new InvalidOperationException("Queue is Empty.");
            var nodeData = _items.Head.Data;
            _items.RemoveFromHead();
            return nodeData;
        }

        public void Enqueue(T data)
        {
            _items.AddToTail(data);
        }

        public void Flip()
        {
            CloneRightToLeft();
        }

        public IEnumerator<T> GetEnumerator()
        {
            return _items.GetEnumerator();
        }

        public bool HasEquivalentContens(IQueue<T> other, IComparer<T> comparer = null)
        {
            if (Count == 0 && other.Count == 0) return true;
            if (comparer == null) comparer = Comparer<T>.Default;

            bool checker = false;
            var tmp = _items.Head;
            var otherTmp = other.CloneLeftToRight();

            while (tmp != _items.Tail)
            {
                while (otherTmp.Count != 0)
                {
                    var comparisonResult = comparer.Compare(tmp.Data, otherTmp.Dequeue());
                    if (comparisonResult == 0)
                    {
                        checker = true;
                        break;
                    }
                }
                if (!checker) return false;
                tmp = tmp.Next;
                otherTmp = other.CloneLeftToRight();
                checker = false;
            }
            while (otherTmp.Count != 0)
            {
                if (comparer.Compare(_items.Tail.Data, otherTmp.Dequeue()) == 0) return true;
            }
            return false;
        }

        public bool HasSameContents(IQueue<T> other, IComparer<T> comparer = null)
        {
            if (Count != other.Count) return false;
            if (Count == 0 && other.Count == 0) return true;
            if (comparer == null) comparer = Comparer<T>.Default;

            var tmp = _items.Head;
            var othertmp = other.CloneLeftToRight();
            while (tmp != _items.Tail)
            {
                var comparisonResult = comparer.Compare(tmp.Data, othertmp.Dequeue());
                if (comparisonResult != 0) return false;
                tmp = tmp.Next;
            }
            if (comparer.Compare(_items.Tail.Data, othertmp.Dequeue()) != 0) return false;
            return true;
        }

        public T Peek()
        {
            if (IsEmpty) throw new InvalidOperationException("Queue is Empty.");
            return _items.Head.Data;
        }

        public void Swap(IQueue<T> other)
        {
            var tmpStack = CloneLeftToRight();
            var tmpOtherStack = other.CloneLeftToRight();

            this.Clear();
            other.Clear();

            while (!tmpOtherStack.IsEmpty)
            {
                Enqueue(tmpOtherStack.Dequeue());
            }
            while (!tmpStack.IsEmpty)
            {
                other.Enqueue(tmpStack.Dequeue());
            }
        }
    }
}
