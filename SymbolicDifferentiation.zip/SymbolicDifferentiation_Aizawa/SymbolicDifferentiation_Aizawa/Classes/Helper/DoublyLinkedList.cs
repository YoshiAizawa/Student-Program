﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SymbolicDifferentiation_Aizawa
{
    public class DoublyLinkedList<T> : ILinkedList<T>
    {

        public Node<T> Head { get; internal set; }
        public Node<T> Tail { get; internal set; }
        public int Count { get; private set; }

        public void AddToHead(T data)
        {
            Count++;
            var x = new Node<T>(data);
            if (Head == null)
            {
                Head = x;
                Tail = x;
                return;
            }

            var tmp = Head;
            Head = x;
            x.Next = tmp;
            tmp.Prev = Head;
        }

        public void AddToTail(T data)
        {
            Count++;
            var x = new Node<T>(data);
            if (Head == null)
            {
                Head = x;
                Tail = x;
                return;
            }
            Tail.Next = x;
            x.Prev = x;
            Tail = x;
        }
        public void RemoveFromHead()
        {
            if (Head == null)
            {
                throw new Exception(message: "Linked list is empty.");
            }
            Count--;
            //if linked list has only one node
            if (Head == Tail)
            {
                Head = null;
                Tail = null;
                return;
            }

            // if linked list has two or more nodes
            Head = Head.Next;
        }
        public void RemoveFromTail()
        {
            if (Head == null)
            {
                throw new Exception(message: "Linked list is empty.");
            }
            Count--;
            //if linked list has only one node
            if (Head == Tail)
            {
                Head = null;
                Tail = null;
                return;
            }

            // if linked list has two or more nodes
            var tmp = Head;
            while (tmp.Next != Tail)
            {
                tmp = tmp.Next;
            }

            Tail = Tail.Prev;
            Tail.Next.Prev = null;
            Tail.Next = null;
        }

        public IEnumerator<T> GetEnumerator()
        {
            if (Head == null) yield break;

            var tmp = Head;
            while (tmp != Tail)
            {
                yield return tmp.Data;
                tmp = tmp.Next;
            }
            yield return Tail.Data;
        }

        public void InsertAt(T data, int position)
        {
            if (position < 0)
                throw new InvalidOperationException("Position must be positive");
            if (position > Count)
                throw new IndexOutOfRangeException("Position is greater than Count");
            if (position == 0)
            {
                AddToHead(data);
                return;
            }

            if (position == Count)
            {
                AddToTail(data);
            }
            //insert between

            if (position > 0 && position < Count)
            {
                var newNode = new Node<T>(data);
                var prev = Head;

                int pos1 = 0;
                var tmp = Head;
                while (tmp != Tail)
                {

                    if (pos1 == position - 1)
                        prev = tmp;
                    tmp = tmp.Next;
                    pos1++;
                }

                var next = prev.Next;

                prev.Next = newNode;
                newNode.Prev = prev;
                newNode.Next = next;
                next.Prev = newNode;
            }
            Count++;
        }



        public Node<T> Search(T dataToSearch, IComparer<T> comparer = null)
        {
            if (comparer == null) comparer = Comparer<T>.Default;

            if (Head == null)
            {
                return null;
            }

            var tmp = Head;
            while (tmp.Next != Tail)
            {
                if (comparer.Compare(tmp.Data, dataToSearch) == 0)
                {
                    return tmp;
                }
                tmp = tmp.Next;
            }
            if (comparer.Compare(Tail.Data, dataToSearch) == 0)
            {
                return Tail;
            }
            return null;
        }

        public int SearchForPosition(T dataToSearch, IComparer<T> comparer = null)
        {
            if (comparer == null) comparer = Comparer<T>.Default;

            if (Head == null)
            {
                return -1;
            }

            int position = 0;
            var tmp = Head;
            while (tmp.Next != Tail)
            {
                position++;
                if (comparer.Compare(tmp.Data, dataToSearch) == 0)
                {
                    return position;
                }
                tmp = tmp.Next;
            }
            if (comparer.Compare(Tail.Data, dataToSearch) == 0)
            {
                position = position + 1;
                return position;
            }
            return -1;
        }

        public void SwapHeadAndTail()
        {
            var tmp = Tail;
            var tmp2 = Head;

            //swapping head to tail
            Head = tmp;
            tmp.Prev = Head.Prev;
            tmp.Prev.Next = Head;
            Head.Next = null;
            tmp = null;

            //swapping tail to head
            Tail = tmp2;
            tmp2.Next = Tail.Next;
            tmp2.Next.Prev = Tail;
            Tail.Prev = null;
            tmp2 = null;
        }

        public void MoveHeadToRight(int moves)
        {
            if (Count < moves)
            {
                throw new Exception(message: "The moves is greater than count");
            }
            //only 1 node
            if (Head == Tail)
            {
                Head = null;
                Tail = null;
                return;
            }

            //two or more node
            var main = Head;
            var tmp = Head;
            for (int x = 0; x < moves; x++)
            {
                tmp = tmp.Next;
                main = tmp;
                if (x == 0)
                {
                    Head = tmp;
                    Head.Next = tmp;
                    Head.Prev = null;
                    main.Prev = Head;
                }
                if (x > 0)
                {
                    main.Prev = tmp.Prev;
                    main.Next = tmp.Next;
                }
                if (x == Count)
                {
                    main.Next = null;
                    Tail = main;
                    main.Prev = tmp.Prev;
                }
            }

        }

        public void MoveHeadToLeft(int moves)
        {
            throw new Exception(message: "You can't move Head to Left.");
        }

        public void MoveTailToRight(int moves)
        {
            throw new Exception(message: "You can't move Tail to Right.");
        }

        public void MoveTailToLeft(int moves)
        {
            var tmpTail = Head;
            var tmp = Tail;
            if (Head == null)
                throw new Exception(message: "LinkedList is empty. ");
            if (Count == moves)
            {
                tmpTail = Head;
                Tail = Tail.Prev;
                Head = tmpTail;
            }

            if (moves > Count)
            {
                throw new IndexOutOfRangeException(message: "Moves is out of range");
            }

            if (moves > 0 && moves < Count)
            {
                int counter = 0;
                while (counter != moves)
                {
                    tmp = tmp.Prev;
                    counter++;
                }

                Tail.Prev = tmpTail;
                tmp = Tail;
                Tail = tmpTail;
            }
        }

        public bool HasSameContents(ILinkedList<T> list, IComparer<T> comparer = null)
        {
            if (Count != list.Count)
                return false;
            if (Count == 0 && list.Count == 0) return true;
            if (comparer == null) comparer = Comparer<T>.Default;

            var tmp = Head;
            var othertmp = list.Head;
            while (tmp != Tail)
            {
                var comparisonResult = comparer.Compare(tmp.Data, othertmp.Data);
                if (comparisonResult != 0) return false;
                tmp = tmp.Next;
                othertmp = othertmp.Next;
            }
            if (comparer.Compare(Tail.Data, list.Tail.Data) != 0) return false;
            return true;
        }

        public void Reverse()
        {
            if (Head == Tail) return;

            var headData = Head.Data;
            var tmpHead = Head;
            var tmp = Tail;

            Head = Tail = null;

            // Reset Count to zero
            Count = 0;
            while (tmp != tmpHead)
            {
                AddToTail(tmp.Data);
                tmp = tmp.Prev;
            }
            AddToTail(headData);
        }
    }
}

