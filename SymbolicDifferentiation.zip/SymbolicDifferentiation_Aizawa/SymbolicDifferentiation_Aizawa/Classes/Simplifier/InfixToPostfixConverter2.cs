﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SymbolicDifferentiation_Aizawa
{
    public class InfixToPostfixConverter2
    {

        private readonly DelimiterMatching _matchChecker = new DelimiterMatching();

        private string PreProcessor(string expression)
        {
            var sb = new StringBuilder(expression);
            if(!_matchChecker.IsOpeningCharacter(sb[0]) && !char.IsLetter(sb[0])) sb.Insert(0, "0");
            char prev = '\0';
            for (var index = 0; index < expression.Length; index++)
            {
                var ch = expression[index];
                if (_matchChecker.IsOpeningCharacter(prev) && ch == '-') sb.Insert(index, "0");
                if (ch == '.' && !char.IsDigit(expression[index - 1])) sb.Insert(index, "0");
                prev = ch;
            }
            sb = SettingFormat(sb);

            return sb.ToString();
        }


        public QueueList<string> ToPostFix(string expression)
        {
            expression = RemoveWhiteSpaceAndCommas(expression);
            expression = PreProcessor(expression);

            var postfix = new QueueList<string>();
            var currentOperand = new StringBuilder();
            var trigoString = new StringBuilder();
            var operatorStack = new StackList<string>();
            foreach (char currentChar in expression)
            {
                if (char.IsDigit(currentChar)) currentOperand.Append(currentChar);
                else if (char.IsLetter(currentChar)) trigoString.Append(currentChar);
                else if (currentChar == '.') currentOperand.Append(currentChar);
                else
                {
                    if (currentOperand.Length > 0)
                    {
                        postfix.Enqueue(currentOperand.ToString());
                        currentOperand.Clear();
                    }

                        if (_matchChecker.IsOpeningCharacter(currentChar)) operatorStack.Push(Convert.ToString(currentChar));
                        else if (_matchChecker.IsClosingCharacter(currentChar))
                        {

                            while (!_matchChecker.IsMatchingDelimiters(operatorStack.Peek(), Convert.ToString(currentChar)))
                            {
                                postfix.Enqueue(operatorStack.Pop().ToString());

                            }
                            // remove the opening character
                            operatorStack.Pop();
                        }
                        else if (IsOperator(Convert.ToString(currentChar)) || IsOperator(trigoString.ToString()))
                        {
                            if (operatorStack.Count == 0)
                            {
                                if ((trigoString.Length == 3 || trigoString.Length == 4))
                                {
                                    operatorStack.Push(trigoString.ToString());
                                    trigoString.Clear();
                                }
                                else operatorStack.Push(Convert.ToString(currentChar));
                            }
                            else
                            {
                                while (operatorStack.Count > 0 && IsOperator(operatorStack.Peek()) &&
                                (HasHigherorEqualPrecedence(operatorStack.Peek(), Convert.ToString(currentChar)) 
                                && HasHigherorEqualPrecedence(operatorStack.Peek(), trigoString.ToString())))
                                {
                                    postfix.Enqueue(operatorStack.Pop().ToString());
                                }
                                


                                if ((trigoString.Length == 3 || trigoString.Length == 4))
                                {
                                    operatorStack.Push(trigoString.ToString());
                                    trigoString.Clear();
                                }
                                else operatorStack.Push(Convert.ToString(currentChar));
                            }
                        }
                }
            }
            if (currentOperand.Length > 0)  postfix.Enqueue(currentOperand.ToString());
            while (operatorStack.Count != 0)
            {
                postfix.Enqueue(operatorStack.Pop().ToString());
            }
            return postfix;
        }


        private string RemoveWhiteSpaceAndCommas(string expression)
        {
            var sb = new StringBuilder(expression);
            sb.Replace(",", string.Empty);
            sb.Replace(" ", string.Empty);
            return sb.ToString();
        }


        private byte GetPrecedence(string mathOperator)
        {
            switch (mathOperator)
            {
                case "+": return 1;
                case "-": return 1;
                case "Sin": return 2;
                case "Cos": return 2;
                case "Tan": return 2;
                case "Csc": return 2;
                case "Sec": return 2;
                case "Cot": return 2;
                case "ASin": return 2;
                case "ACos": return 2;
                case "ATan": return 2;
                case "ACsc": return 2;
                case "ASec": return 2;
                case "ACot": return 2;
                case "*": return 3;
                case "/": return 3;
                case "^": return 4;
                default: return 0;
            }
        }

        private StringBuilder SettingFormat(StringBuilder sb)
        {
            //Trigo
            sb.Replace("sin", "Sin");
            sb.Replace("sIn", "Sin");
            sb.Replace("SIn", "Sin");
            sb.Replace("siN", "Sin");
            sb.Replace("SiN", "Sin");
            sb.Replace("sIN", "Sin");
            sb.Replace("SIN", "Sin");

            sb.Replace("s", "S");
            sb.Replace("In", "in");
            sb.Replace("iN", "in");
            sb.Replace("Ec", "ec");
            sb.Replace("eC", "ec");

            sb.Replace("c", "C");
            sb.Replace("Os", "os");
            sb.Replace("oS", "os");
            sb.Replace("Sc", "sc");
            sb.Replace("sC", "sc");
            sb.Replace("Ot", "ot");
            sb.Replace("oT", "ot");

            sb.Replace("t", "T");
            sb.Replace("An", "an");
            sb.Replace("aN", "an");

            sb.Replace(")(", ")*(");
            sb.Replace("][", "]*[");
            sb.Replace("}{", "}*{");
            sb.Replace("--", "+");
            sb.Replace("+-", "-");
            sb.Replace("-+", "-");
            return sb;
        }

        private bool HasHigherorEqualPrecedence(string mathOperator, string operatorToCompare)
        {
            return GetPrecedence(mathOperator) >= GetPrecedence(operatorToCompare);
        }

        private bool IsOperator(string mathOperator)
        {
            string[] operators = {"+", "-","Sin","Cos","Tan","Csc",
                "Sec", "Cot", "ASin", "ACos", "ATan", "ACsc", "ASec",
                "ASec", "ACot", "*", "/", "^"};

            foreach (var s in operators) if (s == mathOperator) return true;
            return false;
        }

        
    }
}
