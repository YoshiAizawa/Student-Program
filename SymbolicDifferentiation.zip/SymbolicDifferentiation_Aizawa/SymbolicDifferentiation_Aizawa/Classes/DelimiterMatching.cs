﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SymbolicDifferentiation_Aizawa
{
    public class DelimiterMatching
    {
        public bool HasMatchingDelimiters(string expression)
        {
            var charStack = new StackList<char>();
            foreach (var ch in expression)
            {
                if (IsOpeningCharacter(ch)) 
                    charStack.Push(ch);
                else if (IsClosingCharacter(ch))
                {
                    if (charStack.IsEmpty) return false;
                    {
                        char topChOnsStack = charStack.Peek();
                        if (IsMatchingDelimiters(Convert.ToString(topChOnsStack),Convert.ToString(ch)))
                            charStack.Pop();
                        else
                            return false;

                    }
                }
                
            }

            if (!charStack.IsEmpty) return false;

            return true;
        }

        public bool IsMatchingDelimiters(string opening, string closing)
        {
            if (opening == "(" && closing == ")") return true;
            if (opening == "[" && closing == "]") return true;
            if (opening == "{" && closing == "}") return true;
            return false;

        }

        public bool IsClosingCharacter(char ch)
        {
            char[] closings = {')', ']', '}'};
            return ch.ToString().IndexOfAny(closings) >= 0;
        }

        public bool IsOpeningCharacter(char ch)
        {
            char[] openings = {'(', '[', '{'};
            return ch.ToString().IndexOfAny(openings) >= 0;
        }
    }
}
