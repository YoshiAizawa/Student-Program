﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SymbolicDifferentiation_Aizawa
{
    public class DifferentiateExpression
    {
        //public DifferentiateExpression(string expression, char independentVariable)
        //{
        //    Expression = expression;
        //    IndependentVariable = independentVariable;
        //}
        private static readonly DelimiterMatching _matchChecker = new DelimiterMatching();
        public static bool invalidity = false;

        public string Differentiate(string expression, char independentVar)
        {
            expression = PreProcessor(expression,independentVar);

            //additional for parenthesis
            expression = ($"({expression})");

            var sbOutput = new StringBuilder();
            if (!expression.Contains(independentVar))
            {
                sbOutput.Append("0");
            }
            else
            {
                sbOutput.Append(Derivative(expression, independentVar));
            }

            sbOutput = SettingFormat(sbOutput);

            if (invalidity)
            {
                sbOutput.Clear();
                sbOutput.Append("Invalid Expression");
            }

            return sbOutput.ToString();
        }
        private static string PreProcessor(string expression, char independentVar)
        {
            //var stackChecker = new StackList<char>();
            var sb = new StringBuilder();
            var sbTemp = new StringBuilder();
            var operatorLimiter = false;

            //inserting parenthesis in independent variable
            for (var index = 0; index < expression.Length; index++)
            {
                if (index == 0 && expression.Length != 1)
                {
                    sb.Append("(");
                }
                if (index == 0 && expression[0] == '-')
                {
                    sb.Append("0");
                }

                if (_matchChecker.IsOpeningCharacter(expression[index]))
                {
                    //stackChecker.Push(expression[index]);
                    sb.Append(expression[index]);
                }
                else if (expression[index] == independentVar)
                {
                    //if expression is only "x"
                    if (expression.Length == 1 || index==0)
                    {
                        sb.Append($"(1*{expression[index]}^1)");
                    }
                    //checked if the independent variable is the not last part of expression
                    else if (index + 1 != expression.Length)
                    {
                        if (char.IsDigit(expression[index - 1]))
                        {
                            sbTemp.Append("*");
                        }
                        else if (IsUnary(expression[index - 1]))
                        {
                            sbTemp.Append("(1*");
                        }
                        else
                        {
                            sbTemp.Append("1*");
                        }

                        sbTemp.Append(expression[index]);

                        if (expression[index + 1] != '^')
                        {
                            sbTemp.Append("^1");
                        }
                    }
                    else
                    {
                        if (char.IsDigit(expression[index - 1]))
                        {
                            var flag = false;

                            sb.Append("*");
                            for (int tmpIndex = index - 1; tmpIndex > -1; tmpIndex--)
                            {
                                if (IsUnary(expression[tmpIndex])) flag = true;
                            }
                            if (flag) sb.Append(expression[index] + "^1)");
                            else sb.Append(expression[index] + "^1");
                        }
                        else if (IsUnary(expression[index - 1]))
                        {
                            sb.Append("(1*");
                            sb.Append(expression[index] + "^1)");
                        }
                        else
                        {
                            sb.Append("1*");
                            sb.Append(expression[index] + "^1)");
                        }
                    }
                }
                else if (_matchChecker.IsClosingCharacter(expression[index]))
                {
                    //stackChecker.Pop();
                    sb.Append(sbTemp.ToString());
                    sbTemp.Clear();
                    sb.Append(expression[index]);
                }
                //for exponential
                else if (expression[index] == '^' && expression[index - 1] == 'e')
                {
                    sb.Append(expression[index] + "(");
                }
                else if (expression[index] == '^')
                {
                    sb.Append(sbTemp.ToString());
                    sbTemp.Clear();
                    if (char.IsDigit(expression[index - 1])) sb.Append(")");
                    sb.Append(expression[index]);
                }
                else if (expression[index] == '+' || expression[index] == '-')
                {
                    sb.Append(sbTemp.ToString());
                    sbTemp.Clear();
                    //if (expression[index] == '-') sb.Append("+");
                    sb.Append(expression[index]);
                }
                else if (expression[index] == '/' &&
                    !_matchChecker.IsOpeningCharacter(expression[index + 1]) && !operatorLimiter)
                {
                    sb.Append(expression[index]+"(");
                    operatorLimiter = true;
                }
                //else if (char.IsDigit(expression[index]) && index == 0)
                //{
                //    sb.Append("(" + expression[index]);
                //}
                else if (char.IsDigit(expression[index]) && expression.Length == 1)
                {
                    sb.Append(expression[index]);
                }
                else if (char.IsDigit(expression[index]) && index + 1 != expression.Length)
                {
                    if (IsUnary(expression[index + 1])) sb.Append(expression[index] + "*");

                    else if (index != 0)
                    {
                        if (IsUnary(expression[index - 1])) sb.Append("(" + expression[index]);
                        else sb.Append(expression[index]);
                    }

                    else sb.Append(expression[index]);
                }
                else if (char.IsDigit(expression[index]) && IsUnary(expression[index - 1]))
                {
                    sb.Append("(" + expression[index]);
                }
                else sb.Append(expression[index]);

                if (index+1 == expression.Length && expression.Length!=1)
                {
                    while(!_matchChecker.HasMatchingDelimiters(sb.ToString()))
                    sb.Append(")");
                }

                if (index + 1 != expression.Length)
                {
                    if (_matchChecker.IsClosingCharacter(expression[index]) && operatorLimiter)
                    {
                        sb.Append("))");
                        operatorLimiter = false;
                    }
                }
            }

            sb = SettingStartingFormat(sb);

            return sb.ToString();
        }
        private static string Derivative(string expression, char independentVar)
        {
            var sbOutput = new StringBuilder();
            if (expression[0] == independentVar)
            {
                return ("1");
            }
            else if (!expression.Contains(independentVar))
            {
                return ("0");
            }
            switch (Checker(DeletingOuterDelimeter(expression)))
            {
                case -1:
                    sbOutput.Append(Derivative(DeletingOuterDelimeter(expression), independentVar));
                    break;
                case 0:
                    sbOutput.Append(DifferentiateTerm(DeletingOuterDelimeter(expression), independentVar));
                    break;
                case 1:
                    sbOutput.Append(ProductRule(DeletingOuterDelimeter(expression), independentVar));
                    break;
                case 2:
                    sbOutput.Append(DivisionRule(DeletingOuterDelimeter(expression), independentVar));
                    break;
                case 3:
                    sbOutput.Append(PowerRule(DeletingOuterDelimeter(expression), independentVar));
                    break;
                case 4:
                    sbOutput.Append(SumDifferenceRule(DeletingOuterDelimeter(expression), independentVar));
                    break;
                default: break;
            }
            return sbOutput.ToString();
        }
        private static string DifferentiateTerm(string function, char independentVar)
        {
            var stackChecker = new StackList<char>();
            var sbIdentity = new StringBuilder();
            var sbInsideOfIdentity = new StringBuilder();

            //seprating identity and the inside of it
            for (int index = 0; index < function.Length; index++)
            {
                if (_matchChecker.IsOpeningCharacter(function[index]))
                {
                    stackChecker.Push(function[index]);
                    if (!stackChecker.IsEmpty) sbInsideOfIdentity.Append(function[index]);
                }
                else if (_matchChecker.IsClosingCharacter(function[index]))
                {
                    if (!stackChecker.IsEmpty) sbInsideOfIdentity.Append(function[index]);
                    stackChecker.Pop();
                }
                else if (stackChecker.IsEmpty)
                {
                    sbIdentity.Append(function[index]);
                }
                else if (!stackChecker.IsEmpty)
                {
                    sbInsideOfIdentity.Append(function[index]);
                }
            }
            // the expression inside the identity
            
            var identity = sbIdentity.ToString();
            var inner = sbInsideOfIdentity.ToString();
            if (!IsTrigoOrLogarithmic(identity))
            {
                invalidity = true;
            }
            return TrigoOrLogarithmicIdentities(identity, inner, independentVar);
        }
        private static string TrigoOrLogarithmicIdentities(string identity, string inner, char independentVar)
        {
            var sbOutput = new StringBuilder();

            switch (identity)
            {
                case "sin":
                    sbOutput.Append($"cos{inner}*({Derivative(inner,independentVar)})");
                    break;
                case "cos":
                    sbOutput.Append($"-sin{inner}*({Derivative(inner, independentVar)})");
                    break;
                case "tan":
                    sbOutput.Append($"((sec{inner})^2)*({Derivative(inner, independentVar)})");
                    break;
                case "cot":
                    sbOutput.Append($"-((csc{inner})^2)*({Derivative(inner, independentVar)})");
                    break;
                case "sec":
                    sbOutput.Append($"(tan{inner}*sec{inner})*({Derivative(inner, independentVar)})");
                    break;
                case "csc":
                    sbOutput.Append($"-(cot{inner}*csc{inner})*({Derivative(inner, independentVar)})");
                    break;
                case "Asin":
                    sbOutput.Append($"(1/(1-{inner}^2)^(1/2))*({Derivative(inner, independentVar)})");
                    break;
                case "Acos":
                    sbOutput.Append($"-(1/(1-{inner}^2)^(1/2))*({Derivative(inner, independentVar)})");
                    break;
                case "Atan":
                    sbOutput.Append($"(1/(1+{inner}^2))*({Derivative(inner, independentVar)})");
                    break;
                case "Acot":
                    sbOutput.Append($"-(1/(1+{inner}^2))*({Derivative(inner, independentVar)})");
                    break;
                case "Asec":
                    sbOutput.Append($"(1/({inner}*(({inner}^2)-1)^(1/2)))*({Derivative(inner, independentVar)})");
                    break;
                case "Acsc":
                    sbOutput.Append($"-(1/({inner}*(({inner}^2)-1)^(1/2)))*({Derivative(inner, independentVar)})");
                    break;
                case "ln":
                    sbOutput.Append($"(1/{inner})*({Derivative(inner, independentVar)})");
                    break;
                case "e":
                    sbOutput.Append($"({Derivative(inner, independentVar)})*e^({inner})");
                    break;
                case "log":
                    sbOutput.Append($"(1/({inner}*ln(10)))*({Derivative(inner, independentVar)})");
                    break;
                default: break;
            }

            return sbOutput.ToString();
        }
        private static bool IsTrigoOrLogarithmic(string function)
        {
            string[] operators = {"sin","cos","tan","csc",
                "sec", "cot", "Asin", "Acos", "Atan", "Acsc", "Asec",
                "Asec", "Acot", "ln", "e", "log"};

            foreach (var s in operators) if (s == function) return true;
            return false;
        }
        private static bool IsUnary(char unary)
        {
            char[] unaryLetters = {'s','i','n','c','o','t','a',
            'e','l','g','A'};
            foreach (var op in unaryLetters) if (op == unary) return true;
            return false;
        }
        private static string ProductRule(string expression, char independentVar)
        {
            var sb = new StringBuilder();

            if (!expression.Contains("*"))
            {
                sb.Append("1");
                return sb.ToString();
            }
            else
            {
                var stackChecker = new StackList<char>();
                var sbTerms = new StringBuilder();
                for (var index = 0; index < expression.Length; index++)
                {
                    if (_matchChecker.IsOpeningCharacter(expression[index]))
                    {
                        sbTerms.Append(expression[index]);
                        stackChecker.Push(expression[index]);
                    }
                    else if (_matchChecker.IsClosingCharacter(expression[index]))
                    {
                        stackChecker.Pop();
                        sbTerms.Append(expression[index]);
                    }
                    else if (stackChecker.IsEmpty)
                    {
                        if ((expression[index] == '*'))
                        {
                            sbTerms.Append("$");
                        }
                        else sbTerms.Append(expression[index]);
                    }
                    else sbTerms.Append(expression[index]);
                }

                var terms = sbTerms.ToString();
                var term = terms.Split('$');

                sb.Append($"((({term[0]})*({Derivative(term[1], independentVar)}))+" +
                    $"(({term[1]})*({Derivative(term[0], independentVar)})))");
            }

            return sb.ToString();
        }
        private static string DivisionRule(string expression, char independentVar)
        {
            var sb = new StringBuilder();

            if (!expression.Contains("/"))
            {
                sb.Append("1");
                return sb.ToString();
            }
            else
            {
                var stackChecker = new StackList<char>();
                var sbTerms = new StringBuilder();
                for (var index = 0; index < expression.Length; index++)
                {
                    if (_matchChecker.IsOpeningCharacter(expression[index]))
                    {
                        sbTerms.Append(expression[index]);
                        stackChecker.Push(expression[index]);
                    }
                    else if (_matchChecker.IsClosingCharacter(expression[index]))
                    {
                        stackChecker.Pop();
                        sbTerms.Append(expression[index]);
                    }
                    else if (stackChecker.IsEmpty)
                    {
                        if ((expression[index] == '/'))
                        {
                            sbTerms.Append("$");
                        }
                        else sbTerms.Append(expression[index]);
                    }
                    else sbTerms.Append(expression[index]);
                }

                var terms = sbTerms.ToString();
                var term = terms.Split('$');
                sb.Append($"((({term[1]})*({Derivative(term[0], independentVar)}))-" +
                    $"(({term[0]})*({Derivative(term[1], independentVar)})))/({term[1]})^2");
            }

            return sb.ToString();
        }
        private static string PowerRule(string expression, char independentVar)
        {
            //1*x^1
            var sbOutput = new StringBuilder();

            if (!expression.Contains('^'))
            {
                sbOutput.Append("*1");
                return sbOutput.ToString();
            }
            else
            {
                var stackChecker = new StackList<char>();
                var sbTerms = new StringBuilder();
                for (var index = 0; index < expression.Length; index++)
                {
                    if (_matchChecker.IsOpeningCharacter(expression[index]))
                    {
                        sbTerms.Append(expression[index]);
                        stackChecker.Push(expression[index]);
                    }
                    else if (_matchChecker.IsClosingCharacter(expression[index]))
                    {
                        stackChecker.Pop();
                        sbTerms.Append(expression[index]);
                    }
                    else if (stackChecker.IsEmpty)
                    {
                        if ((expression[index] == '^'))
                        {
                            sbTerms.Append("$");
                        }
                        else sbTerms.Append(expression[index]);
                    }
                    else sbTerms.Append(expression[index]);
                }

                var terms = sbTerms.ToString();

                var indexOfPower = terms.IndexOf('$');
                var term = terms.Split('$');
                if (term[0][term[0].Length - 1] == 'e')
                {
                    sbOutput.Append($"(({Derivative(term[1], independentVar)})*({term[0]})^({term[1]}))");
                    return sbOutput.ToString();
                }
                //if exponent has independent variable
                else if (term[1].Contains(independentVar))
                {
                    //checking if the term[0] is constant
                    if (!term[0].Contains(independentVar))
                    {
                        
                        sbOutput.Append($"({expression})*(ln({term[0]}))*({Derivative(term[1], independentVar)})");
                        return sbOutput.ToString();
                    }
                    else
                    {
                        sbOutput.Append($"({expression})*({Derivative($"(ln({term[0]})*({term[1]}))",independentVar)})");
                        return sbOutput.ToString();
                    }
                }
                else if (term[1] != "1" && term[1] != "0")
                {
                    if (_matchChecker.IsOpeningCharacter(term[1][0])) term[1] = DeletingOuterDelimeter(term[1]);
                    sbOutput.Append($"({term[1]}*({term[0]}^{Convert.ToDecimal(term[1]) - 1}))");

                    if (expression[indexOfPower - 1] == independentVar)
                    {
                        return sbOutput.ToString();
                    }
                    else
                    {
                        sbOutput.Append($"*({Derivative((term[0]), independentVar)})");
                        return sbOutput.ToString();
                    }
                }
                else if (term[1] == "1")
                {
                    var constant = term[0].Split('*');
                    sbOutput.Append(constant[0]);
                    return sbOutput.ToString();
                }
                else
                {
                    sbOutput.Append("+0");
                    return sbOutput.ToString();
                }
            }
        }
        private static string SumDifferenceRule(string expression, char independentVar)
        {
            var sbTerms = new StringBuilder();
            var stackChecker = new StackList<char>();
            var queueOperand = new QueueList<char>();

            var sbOutput = new StringBuilder();

            //Sum and Difference Rule
            for (var index = 0; index < expression.Length; index++)
            {
                if (_matchChecker.IsOpeningCharacter(expression[index]))
                {
                    sbTerms.Append(expression[index]);
                    stackChecker.Push(expression[index]);
                }
                else if (_matchChecker.IsClosingCharacter(expression[index]))
                {
                    stackChecker.Pop();
                    sbTerms.Append(expression[index]);
                }
                else if (stackChecker.IsEmpty)
                {
                    if ((expression[index] == '+') || expression[index] =='-')
                    {
                        queueOperand.Enqueue(expression[index]);
                        sbTerms.Append("$");
                    }
                    else sbTerms.Append(expression[index]);
                }
                else sbTerms.Append(expression[index]);
            }

            var terms = sbTerms.ToString().Split('$');
            var firstTerm = true;
            foreach(var term in terms)
            {
                if (firstTerm)
                {
                    sbOutput.Append(Derivative($"({(term)})", independentVar));
                    firstTerm = false;
                }
                else
                {
                    sbOutput.Append($"{queueOperand.Peek()}({(Derivative($"({(term)})", independentVar))})");
                    queueOperand.Dequeue();
                }
            }

            return sbOutput.ToString();
        }
        private static int Checker(string expression)
        {
            var stackChecker = new StackList<char>();
            var queueOperand = new QueueList<char>();
            int precedence = -1;
            for (var index = 0; index < expression.Length; index++)
            {
                if (_matchChecker.IsOpeningCharacter(expression[index]))
                {
                    stackChecker.Push(expression[index]);
                }
                else if (_matchChecker.IsClosingCharacter(expression[index]))
                {
                    stackChecker.Pop();
                }
                else if (stackChecker.IsEmpty)
                {
                    if (IsOperator(expression[index]) || IsUnary(expression[index]))
                        queueOperand.Enqueue(expression[index]);
                }
            }
            
            while (!queueOperand.IsEmpty)
            {
                if (GetPrecedence(queueOperand.Peek()) > precedence)
                    precedence = GetPrecedence(queueOperand.Peek());
                queueOperand.Dequeue();
            }

            return precedence;
        }
        private static bool IsOperator(char mathOperator)
        {
            char[] operators = { '+', '-', '*', '/', '^' };
            foreach (var op in operators)if (op == mathOperator)return true;
            return false;
        }
        private static byte GetPrecedence(char mathOperator)
        {
            switch (mathOperator)
            {
                case '*': return 1;
                case '/': return 2;
                case '^': return 3;
                case '-': return 4;
                case '+': return 4;
                default: return 0;
            }
        }
        private static string DeletingOuterDelimeter(string expression)
        {
            var sb = new StringBuilder();
            var stackChecker = new StackList<char>();
            if (_matchChecker.IsOpeningCharacter(expression[0]))
            {
                for (var index = 0; index < expression.Length; index++)
                {
                    if (_matchChecker.IsOpeningCharacter(expression[index]))
                    {
                        if (!stackChecker.IsEmpty) sb.Append(expression[index]);
                        stackChecker.Push(expression[index]);
                    }
                    else if (_matchChecker.IsClosingCharacter(expression[index]))
                    {
                        stackChecker.Pop();
                        if (!stackChecker.IsEmpty) sb.Append(expression[index]);
                    }
                    else if (!stackChecker.IsEmpty)
                    {
                        sb.Append(expression[index]);
                    }
                    else if (IsOperator(expression[index]))
                    {
                        sb.Append(expression[index]);
                    }
                }
                return sb.ToString();
            }

            return expression;
        }
        private static StringBuilder SettingFormat(StringBuilder sb)
        {
            sb.Replace("*1", string.Empty);
            sb.Replace("1*", string.Empty);
            if(!sb.ToString().Contains("x^11")) sb.Replace("^1", string.Empty);
            sb.Replace("^0", string.Empty);
            sb.Replace("*(1)", string.Empty);
            sb.Replace("+(0)", string.Empty);
            sb.Replace("-(0)", string.Empty);
            sb.Replace("0+", string.Empty);
            sb.Replace("0-", "-");
            sb.Replace("*x", "x");
            sb.Replace(")(", ")*(");
            sb.Replace("][", "]*[");
            sb.Replace("}{", "}*{");
            sb.Replace("--", "+");
            sb.Replace("+-", "-");
            sb.Replace("-+", "-");
            return sb;
        }
        private static StringBuilder SettingStartingFormat(StringBuilder sb)
        {
            sb.Replace(")(", ")*(");
            sb.Replace("][", "]*[");
            sb.Replace("}{", "}*{");
            return sb;
        }
    }
}
