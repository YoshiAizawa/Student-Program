﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MaterialDesignThemes;
using MaterialDesignColors;

namespace SymbolicDifferentiation_Aizawa
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Dragger(object sender, MouseButtonEventArgs e)
        {
            try
            {
                DragMove();
            }
            catch (Exception)
            {
                //throw
            }
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnHelp_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Trigonometric funtion: " +
                            "\nsinx = sin(x)" +
                            "\ncosx = cos(x)" +
                            "\narctanx = Atan(x)" + 
                            "\narccotx = Acot(x)" +
                            "\nsecx = sec(x)" +
                            "\ncscx = csc(x)" +
                            "\n\nLogarithmic Funtion:" +
                            "\nlnx = ln(x)" +
                            "\nlogx = log(x)" +
                            "\ne^x = e^(x)" +
                            "\n\nInsert Parenthesis Correctly!" +
                            "\ne.g.) ((4x+2)^2)/((3x+2)^3)"+
                            "\n      3x^(4+x)"
                            ,"Help", MessageBoxButton.OK, MessageBoxImage.Question);
            
        }

        private void BtnSolve_Click(object sender, RoutedEventArgs e)
        {
            txtResult.Clear();
            if (txtSolve.Text == string.Empty)
            {
                MessageBox.Show("Fill in the textbox", "Empty Textbox", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                var diff = new DifferentiateExpression();

                txtResult.Text = diff.Differentiate(txtSolve.Text, Convert.ToChar(cmbIndependentVariable.Text));
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            txtSolve.Clear();
            txtResult.Clear();
        }
    }
}
